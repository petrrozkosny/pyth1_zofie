
# naimportuj pandas a numpy
import pandas as pd
import numpy as np

# nacti csv
df = pd.read_csv('https://raw.githubusercontent.com/mlcollege/ai-academy/main/07-unsupervised-learning/data/iris.csv')
# vyber prvnich 5 radku
print(df.head())
