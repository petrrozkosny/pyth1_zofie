


class Kurz:
    def __init__(self,nazev_kurzu):
        self.kurz = nazev_kurzu





ucebna3 = Kurz('Python')
ucebna2 = Kurz('JAVA')
print(ucebna3.kurz)
print(ucebna2.kurz)
