import pandas as pd 

df = pd.read_csv(r'https://raw.githubusercontent.com/petrrozkosny/pydata/main/pydata_data.csv',sep=	';')
print(df.shape())