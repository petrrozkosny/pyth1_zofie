
def kurz(kurz='Python'):
    print(f'Kurz {kurz}')







if __name__ == '__main__':
    kurz(kurz='JAVA')